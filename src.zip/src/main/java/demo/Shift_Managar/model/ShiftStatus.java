package demo.Shift_Managar.model;

public enum ShiftStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
