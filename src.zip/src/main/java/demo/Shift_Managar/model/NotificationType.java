package demo.Shift_Managar.model;

public enum NotificationType {
    SHIFT_ASSIGNED,
    SHIFT_CHANGED,
    SHIFT_CANCELLED,
    SHIFT_REMINDER,
    GENERAL
}
