package demo.Shift_Managar.model;

public enum UserRole {
    ADMIN,
    EMPLOYEE
}
