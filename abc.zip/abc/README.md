# StudyHub — Frontend (React + Vite + Tailwind)

This repository contains a frontend-only React implementation of StudyHub (client-side only, localStorage-backed fake API).

Quick start (Windows PowerShell):

```powershell
# install deps
npm install

# start dev server
npm run dev
```

Files of interest:
- `src/main.jsx` — app entry
- `src/App.jsx` — top-level routing and nav
- `src/components/` — core UI components: `AuthView`, `ProfileView`, `FeedView`, `StudyGroupsView`, `AIAssistantView`, `MessagesView`
- `src/services/fakeApi.js` — simple localStorage-based API and auth simulation

Notes:
- This is client-only. For production, replace the `fakeApi` with real backend endpoints.
- The AI assistant is simulated locally. Integrate your server-side AI proxy to call models like Claude Haiku 4.5.

Next steps I can do for you:
- Add a lightweight Express server with API proxy routes for AI and persistence.
- Integrate real authentication (JWT) and storage (Postgres).
- Polish UI and add tests.

Tell me which next step you'd like me to take.
