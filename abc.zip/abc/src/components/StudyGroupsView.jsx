import React, { useEffect, useState } from 'react'
import { api, auth } from '../services/fakeApi'

export default function StudyGroupsView() {
  const [groups, setGroups] = useState([])
  const [form, setForm] = useState({ name: '', subject: '', course: '', description: '' })
  const user = auth.getCurrentUser()

  useEffect(() => { load() }, [])
  async function load() { const g = await api.listGroups(); setGroups(g) }

  async function create(e) {
    e.preventDefault()
    if (!user) return alert('Login to create groups')
    await api.createGroup({ ...form, ownerId: user.id })
    setForm({ name: '', subject: '', course: '', description: '' })
    load()
  }

  async function join(id) {
    if (!user) return alert('Login to join')
    await api.joinGroup(id, user.id); load()
  }

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-3 gap-6">
      <div className="col-span-2">
        <h3 className="text-lg font-semibold mb-3">Explore Study Groups</h3>
        <div className="space-y-3">
          {groups.map(g => (
            <div className="bg-white/80 p-4 rounded flex justify-between" key={g.id}>
              <div>
                <div className="font-semibold">{g.name} <span className="text-sm text-slate-500">({g.subject})</span></div>
                <div className="text-sm text-slate-600">{g.description}</div>
                <div className="text-xs text-slate-500 mt-1">Members: {g.members.length}</div>
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => join(g.id)} className="px-3 py-1 bg-sky-600 text-white rounded text-sm">Join</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <aside className="bg-white/80 p-4 rounded">
        <h4 className="font-semibold">Create Group</h4>
        <form onSubmit={create} className="space-y-2 mt-2">
          <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Group name" className="w-full p-2 border rounded" />
          <input value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} placeholder="Subject" className="w-full p-2 border rounded" />
          <input value={form.course} onChange={e => setForm({ ...form, course: e.target.value })} placeholder="Course (optional)" className="w-full p-2 border rounded" />
          <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Short description" className="w-full p-2 border rounded" rows={3} />
          <div className="flex justify-end">
            <button className="px-3 py-1 bg-sky-600 text-white rounded">Create</button>
          </div>
        </form>
      </aside>
    </div>
  )
}
