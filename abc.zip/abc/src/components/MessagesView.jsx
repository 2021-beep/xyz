import React, { useEffect, useState } from 'react'
import { api, auth } from '../services/fakeApi'

export default function MessagesView() {
  const user = auth.getCurrentUser()
  const [conversations, setConversations] = useState([])
  const [users, setUsers] = useState([])
  const [toEmail, setToEmail] = useState('')
  const [text, setText] = useState('')

  useEffect(() => { loadUsers(); loadMessages() }, [])

  async function loadUsers() { const u = await api.listUsers(); setUsers(u) }
  async function loadMessages() { if (!user) return setConversations([]); const m = await api.listMessagesForUser(user.id); setConversations(m) }

  async function start() {
    if (!user) return alert('Login to message')
    const recipient = await api.getUserByEmail(toEmail)
    if (!recipient) return alert('No user with that email')
    await api.sendMessage({ from: user.id, to: recipient.id, text })
    setText(''); setToEmail(''); loadMessages()
  }

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-3 gap-6">
      <div className="col-span-2">
        <h3 className="text-lg font-semibold mb-3">Messages</h3>
        <div className="space-y-3">
          {conversations.map(m => (
            <div key={m.id} className="bg-white/80 p-3 rounded">
              <div className="text-sm text-slate-600">{new Date(m.createdAt).toLocaleString()}</div>
              <div className="mt-1">From: {m.from} — To: {m.to}</div>
              <div className="mt-2">{m.text}</div>
            </div>
          ))}
        </div>
      </div>

      <aside className="bg-white/80 p-4 rounded">
        <h4 className="font-semibold">Start Conversation</h4>
        <div className="mt-2 space-y-2">
          <input value={toEmail} onChange={e => setToEmail(e.target.value)} placeholder="Recipient email" className="w-full p-2 border rounded" />
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder="Message" className="w-full p-2 border rounded" rows={4} />
          <div className="flex justify-end">
            <button onClick={start} className="px-3 py-1 bg-sky-600 text-white rounded">Send</button>
          </div>
        </div>
      </aside>
    </div>
  )
}
