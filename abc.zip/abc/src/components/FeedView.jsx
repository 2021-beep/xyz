import React, { useEffect, useState } from 'react'
import { api, auth } from '../services/fakeApi'

export default function FeedView() {
  const [posts, setPosts] = useState([])
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const user = auth.getCurrentUser()

  useEffect(() => { load() }, [])
  async function load() { const p = await api.listPosts(); setPosts(p) }

  async function submit(e) {
    e.preventDefault()
    if (!user) return alert('Login to create posts')
    await api.createPost({ authorId: user.id, title, content })
    setTitle(''); setContent(''); load()
  }

  async function like(id) { await api.likePost(id); load() }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white/80 p-4 rounded mb-6">
        <h3 className="font-semibold mb-2">Create Post</h3>
        <form onSubmit={submit} className="space-y-2">
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" className="w-full p-2 border rounded" />
          <textarea value={content} onChange={e => setContent(e.target.value)} placeholder="Share your insight or question..." className="w-full p-2 border rounded" rows={4} />
          <div className="flex justify-end">
            <button className="px-4 py-2 bg-sky-600 text-white rounded">Post</button>
          </div>
        </form>
      </div>

      <div className="space-y-4">
        {posts.map(p => (
          <article className="bg-white/80 p-4 rounded" key={p.id}>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-semibold">{p.title}</div>
                <div className="text-sm text-slate-600">{new Date(p.createdAt).toLocaleString()}</div>
              </div>
              <div className="text-sm text-slate-600">❤️ {p.likes || 0}</div>
            </div>
            <p className="mt-2">{p.content}</p>
            <div className="mt-3 flex gap-2">
              <button onClick={() => like(p.id)} className="px-3 py-1 border rounded text-sm">Like</button>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
