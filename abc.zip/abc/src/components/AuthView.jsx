import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { auth } from '../services/fakeApi'

export default function AuthView() {
  const [isRegister, setIsRegister] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', password: '', major: '', year: '' })
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  function onChange(e) { setForm({ ...form, [e.target.name]: e.target.value }) }

  async function submit(e) {
    e.preventDefault(); setError(null)
    try {
      if (isRegister) await auth.register(form)
      else await auth.login(form)
      navigate('/feed')
    } catch (err) {
      setError(err.message || 'Submission failed')
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white/80 p-6 rounded-lg shadow">
      <h2 className="text-xl font-semibold mb-4">{isRegister ? 'Create account' : 'Welcome back'}</h2>
      <form onSubmit={submit} className="space-y-3">
        {isRegister && (
          <input name="name" placeholder="Full name" value={form.name} onChange={onChange} className="w-full p-2 border rounded" />
        )}
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={onChange} className="w-full p-2 border rounded" />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={onChange} className="w-full p-2 border rounded" />
        {isRegister && (
          <div className="grid grid-cols-2 gap-2">
            <input name="major" placeholder="Major" value={form.major} onChange={onChange} className="p-2 border rounded" />
            <input name="year" placeholder="Year" value={form.year} onChange={onChange} className="p-2 border rounded" />
          </div>
        )}
        {error && <div className="text-red-600">{error}</div>}
        <div className="flex items-center justify-between">
          <button className="px-4 py-2 bg-sky-600 text-white rounded">{isRegister ? 'Sign up' : 'Login'}</button>
          <button type="button" onClick={() => setIsRegister(!isRegister)} className="text-sm text-slate-600">{isRegister ? 'Have an account? Login' : 'Create an account'}</button>
        </div>
      </form>
    </div>
  )
}
