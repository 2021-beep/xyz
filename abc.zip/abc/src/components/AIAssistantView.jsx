import React, { useEffect, useState } from 'react'
import { auth } from '../services/fakeApi'

// This component simulates an AI assistant locally. Replace sendToServer with a real API call when backend exists.
function fakeAIReply(question, profile) {
  const profileHint = profile ? `${profile.name} (${profile.major})` : 'student'
  if (!question) return 'Ask me something about your courses, projects, or study plan.'
  if (question.toLowerCase().includes('plan')) return `Hi ${profileHint}, build a weekly study plan: review lecture notes M/W, do practice problems T/Th, and a mock test on Saturday.`
  if (question.toLowerCase().includes('explain')) return `Here's a short explanation: ${question} — try breaking it into steps and practicing with small examples.`
  return `I suggest: review recent slides, summarize key points, and try a short quiz. (Simulated response)`
}

export default function AIAssistantView() {
  const user = auth.getCurrentUser()
  const [messages, setMessages] = useState([{ role: 'assistant', content: 'Hello — I can help with study plans, explanations, and resources.' }])
  const [text, setText] = useState('')

  useEffect(() => {
    // Could fetch feature flag / config here
  }, [])

  async function send() {
    if (!text) return
    const userMsg = { role: 'user', content: text }
    setMessages(m => [...m, userMsg])
    setText('')
    // simulate AI response
    const resp = fakeAIReply(text, user)
    setTimeout(() => setMessages(m => [...m, { role: 'assistant', content: resp }]), 500)
  }

  return (
    <div className="max-w-3xl mx-auto bg-white/80 p-4 rounded">
      <h3 className="font-semibold mb-2">AI Learning Assistant</h3>
      <div className="min-h-[200px] border rounded p-3 bg-white/90 overflow-auto">
        {messages.map((m, i) => (
          <div key={i} className={`mb-2 ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
            <div className={`inline-block p-2 rounded ${m.role === 'user' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
              {m.content}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <input value={text} onChange={e => setText(e.target.value)} placeholder="Ask a study question..." className="flex-1 p-2 border rounded" />
        <button onClick={send} className="px-3 py-1 bg-sky-600 text-white rounded">Send</button>
      </div>
    </div>
  )
}
