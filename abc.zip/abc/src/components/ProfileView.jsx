import React, { useEffect, useState } from 'react'
import { auth, api } from '../services/fakeApi'

export default function ProfileView() {
  const [user, setUser] = useState(auth.getCurrentUser())
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState(user || {})

  useEffect(() => {
    setUser(auth.getCurrentUser())
    setForm(auth.getCurrentUser() || {})
  }, [])

  function onChange(e) { setForm({ ...form, [e.target.name]: e.target.value }) }

  async function save() {
    await auth.updateProfile(form)
    setEditing(false)
    setUser(auth.getCurrentUser())
  }

  if (!user) return <div>Please login to view your profile.</div>

  return (
    <div className="max-w-2xl mx-auto bg-white/80 p-6 rounded shadow">
      <div className="flex items-start gap-4">
        <div className="w-20 h-20 bg-sky-200 rounded-full flex items-center justify-center text-xl">{user.name[0]}</div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold">{user.name}</h3>
          <p className="text-sm text-slate-600">{user.major} — Year {user.year}</p>
        </div>
        <div>
          <button onClick={() => setEditing(!editing)} className="px-3 py-1 border rounded">{editing ? 'Cancel' : 'Edit'}</button>
        </div>
      </div>

      {editing ? (
        <div className="mt-4 space-y-3">
          <input name="name" value={form.name || ''} onChange={onChange} className="w-full p-2 border rounded" />
          <input name="bio" value={form.bio || ''} onChange={onChange} className="w-full p-2 border rounded" placeholder="Short bio" />
          <input name="skills" value={(form.skills || []).join(', ')} onChange={e => setForm({ ...form, skills: e.target.value.split(',').map(s => s.trim()) })} className="w-full p-2 border rounded" placeholder="Comma separated skills" />
          <div className="flex justify-end">
            <button onClick={save} className="px-4 py-2 bg-sky-600 text-white rounded">Save</button>
          </div>
        </div>
      ) : (
        <div className="mt-4">
          <p className="mb-2"><strong>Bio:</strong> {user.bio || '—'}</p>
          <p className="mb-2"><strong>Skills:</strong> {(user.skills || []).join(', ') || '—'}</p>
          <p className="mb-2"><strong>Interests:</strong> {(user.interests || []).join(', ') || '—'}</p>
        </div>
      )}
    </div>
  )
}
