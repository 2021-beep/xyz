import { load, save } from './storage'

const STORAGE_KEYS = {
  users: 'studyhub_users_v1',
  posts: 'studyhub_posts_v1',
  groups: 'studyhub_groups_v1',
  messages: 'studyhub_messages_v1',
}

// init seed
const seedUsers = [
  { id: 'u1', name: 'Alice Student', email: 'alice@example.com', major: 'CS', year: '3', bio: 'Loves algorithms', skills: ['React'] },
  { id: 'u2', name: 'Bob Learner', email: 'bob@example.com', major: 'Math', year: '2', bio: 'Statistics enthusiast', skills: ['Python'] },
]

function ensureSeed() {
  if (!load(STORAGE_KEYS.users)) save(STORAGE_KEYS.users, seedUsers)
  if (!load(STORAGE_KEYS.posts)) save(STORAGE_KEYS.posts, [])
  if (!load(STORAGE_KEYS.groups)) save(STORAGE_KEYS.groups, [])
  if (!load(STORAGE_KEYS.messages)) save(STORAGE_KEYS.messages, [])
}

ensureSeed()

function uid(prefix = '') {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
}

export const auth = (function () {
  let currentUser = load('studyhub_current_user') || null
  const subs = new Set()

  function persist() {
    if (currentUser) save('studyhub_current_user', currentUser)
    else localStorage.removeItem('studyhub_current_user')
  }

  return {
    getCurrentUser() { return currentUser },
    subscribe(cb) { subs.add(cb); return () => subs.delete(cb) },
    _notify() { subs.forEach(s => s(currentUser)) },

    async register({ name, email, password, major, year }) {
      const users = load(STORAGE_KEYS.users, [])
      if (users.find(u => u.email === email)) throw new Error('Email already registered')
      const newUser = { id: uid('u'), name, email, password, major, year, bio: '', skills: [], interests: [] }
      users.push(newUser)
      save(STORAGE_KEYS.users, users)
      currentUser = { ...newUser }
      persist(); this._notify()
      return currentUser
    },

    async login({ email, password }) {
      const users = load(STORAGE_KEYS.users, [])
      const u = users.find(x => x.email === email && x.password === password)
      if (!u) throw new Error('Invalid credentials')
      currentUser = { ...u }
      persist(); this._notify()
      return currentUser
    },

    logout() { currentUser = null; persist(); this._notify() },

    async updateProfile(patch) {
      if (!currentUser) throw new Error('Not authenticated')
      const users = load(STORAGE_KEYS.users, [])
      const idx = users.findIndex(u => u.id === currentUser.id)
      if (idx === -1) throw new Error('User not found')
      users[idx] = { ...users[idx], ...patch }
      save(STORAGE_KEYS.users, users)
      currentUser = { ...users[idx] }
      persist(); this._notify()
      return currentUser
    }
  }
})()

export const api = (function () {
  return {
    // posts
    listPosts() { return Promise.resolve(load(STORAGE_KEYS.posts, []).slice().reverse()) },
    createPost({ authorId, title, content, tags = [] }) {
      const posts = load(STORAGE_KEYS.posts, [])
      const p = { id: uid('p'), authorId, title, content, tags, createdAt: Date.now(), likes: 0 }
      posts.push(p); save(STORAGE_KEYS.posts, posts); return Promise.resolve(p)
    },
    likePost(postId) {
      const posts = load(STORAGE_KEYS.posts, [])
      const p = posts.find(x => x.id === postId)
      if (!p) return Promise.reject(new Error('Not found'))
      p.likes = (p.likes || 0) + 1; save(STORAGE_KEYS.posts, posts); return Promise.resolve(p)
    },

    // groups
    listGroups() { return Promise.resolve(load(STORAGE_KEYS.groups, [])) },
    createGroup({ name, subject, course, description, privacy = 'public', ownerId }) {
      const groups = load(STORAGE_KEYS.groups, [])
      const g = { id: uid('g'), name, subject, course, description, privacy, ownerId, members: [ownerId], createdAt: Date.now() }
      groups.push(g); save(STORAGE_KEYS.groups, groups); return Promise.resolve(g)
    },
    joinGroup(groupId, userId) {
      const groups = load(STORAGE_KEYS.groups, [])
      const g = groups.find(x => x.id === groupId)
      if (!g) return Promise.reject(new Error('Group not found'))
      if (!g.members.includes(userId)) g.members.push(userId)
      save(STORAGE_KEYS.groups, groups); return Promise.resolve(g)
    },

    // messages
    listMessagesForUser(userId) {
      const all = load(STORAGE_KEYS.messages, [])
      return Promise.resolve(all.filter(m => m.to === userId || m.from === userId))
    },
    sendMessage({ from, to, text }) {
      const messages = load(STORAGE_KEYS.messages, [])
      const m = { id: uid('m'), from, to, text, createdAt: Date.now(), read: false }
      messages.push(m); save(STORAGE_KEYS.messages, messages); return Promise.resolve(m)
    },

    // users
    listUsers() { return Promise.resolve(load(STORAGE_KEYS.users, [])) },
    getUserByEmail(email) {
      const users = load(STORAGE_KEYS.users, [])
      return Promise.resolve(users.find(u => u.email === email))
    }
  }
})()
