import React, { useEffect, useState } from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import AuthView from './components/AuthView'
import ProfileView from './components/ProfileView'
import FeedView from './components/FeedView'
import StudyGroupsView from './components/StudyGroupsView'
import AIAssistantView from './components/AIAssistantView'
import MessagesView from './components/MessagesView'
import { auth, api } from './services/fakeApi'

export default function App() {
  const [user, setUser] = useState(auth.getCurrentUser())
  const navigate = useNavigate()

  useEffect(() => {
    const unsub = auth.subscribe(u => setUser(u))
    return unsub
  }, [])

  function handleLogout() {
    auth.logout()
    navigate('/')
  }

  return (
    <div className="min-h-screen">
      <header className="bg-white/60 backdrop-blur sticky top-0 z-20">
        <div className="container mx-auto flex items-center justify-between p-4">
          <Link to="/" className="text-2xl font-semibold text-sky-700">StudyHub</Link>
          <nav className="flex items-center gap-4">
            <Link to="/feed" className="text-slate-700">Feed</Link>
            <Link to="/groups" className="text-slate-700">Groups</Link>
            <Link to="/ai" className="text-slate-700">AI Assistant</Link>
            <Link to="/messages" className="text-slate-700">Messages</Link>
            {user ? (
              <>
                <Link to="/profile" className="px-3 py-1 bg-sky-600 text-white rounded">{user.name}</Link>
                <button onClick={handleLogout} className="px-3 py-1 border rounded">Logout</button>
              </>
            ) : (
              <Link to="/auth" className="px-3 py-1 bg-sky-600 text-white rounded">Login / Sign up</Link>
            )}
          </nav>
        </div>
      </header>

      <main className="container mx-auto p-4">
        <Routes>
          <Route path="/" element={<FeedView />} />
          <Route path="/feed" element={<FeedView />} />
          <Route path="/auth" element={<AuthView />} />
          <Route path="/profile" element={<ProfileView />} />
          <Route path="/groups" element={<StudyGroupsView />} />
          <Route path="/ai" element={<AIAssistantView />} />
          <Route path="/messages" element={<MessagesView />} />
        </Routes>
      </main>

      <footer className="text-center p-6 text-sm text-slate-500">
        © {new Date().getFullYear()} StudyHub — built for students
      </footer>
    </div>
  )
}
